<!DOCTYPE html>
<html lang="en">
<body>
        <nav>
            <a href="/">Home</a>
            <a href="/about">About</a>
            <a href="/contact">Contact</a>
        </nav>
        
    
    </body>

    {{$slot}}