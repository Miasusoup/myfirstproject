
<x-layout>
    <h1>Hello from About Page </h1>
</x-layout>

