<x-layout>
    <h1>Hello from  Contact Page </h1>
</x-layout>